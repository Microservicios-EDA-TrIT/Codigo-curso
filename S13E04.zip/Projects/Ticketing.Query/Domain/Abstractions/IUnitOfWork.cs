namespace Ticketing.Query.Domain.Abstractions;

public interface IUnitOfWork
{
    IGenericRepository<TEntity> RepositoyGeneric<TEntity>() where TEntity: class;

    Task<int> Complete();
}
