namespace Ticketing.Command.Features.Apis;

public interface IMinimalApi
{
    void AddEndpoint(IEndpointRouteBuilder endpointRouteBuilder);
}