﻿namespace Common.Core;

public class Class1
{

}
